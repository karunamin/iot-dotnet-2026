﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CefSharp.Wpf;

namespace WpfTestApp
{
    /// <summary>
    /// WebTestWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class WebTestWindow : Window
    {
        public WebTestWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string url = "https://www.google.com";

            WebBrowser.Address = url;
        }
    }
}
